# M5 PR5.1 Recovery Overlay

This overlay restores Python and native runtime files omitted from an
incomplete repository snapshot.

Apply over the repository root, remove `RECOVERY.md`, then run:

```bash
./scripts/fix-pr5.1-recovery.sh
uv sync --project compiler --extra dev
uv run --project compiler ruff check compiler/src compiler/tests
uv run --project compiler ruff format --check compiler/src compiler/tests
uv run --project compiler pytest
make -C runtimes/amiga-native clean
make -C runtimes/amiga-native test CC=/usr/bin/gcc
./scripts/check-repository-hygiene.sh
```
