# M4 PR3 target validation fix

Restores text, choice and jump target validation lost during PR3 integration.
