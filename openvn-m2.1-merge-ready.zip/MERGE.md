
Merge-ready overlay.

Copy these files into the repository root.

Delete any previous temporary delivery files:

DELIVERY.md
DELIVERY-M2-FIX.md
README-patch.md
README-replacement.md
CHANGELOG-patch.md
VERIFICATION.md
ci-snippet.yml
REMOVE-FILES.txt
