# OpenVN M7 PR4 — Amiga Render Diagnostics

This delivery instruments the native Amiga graphics path without changing its rendering behavior.

It writes `openvn-render.log` in the OpenVN application directory and traces:

- graphics/display opening
- background and character asset lookup
- ILBM loading and decoded image metadata
- planar conversion
- Amiga bitmap allocation
- palette conversion and upload
- background/character blits
- final display presentation

## Apply

```bash
cd ~/Projects/openvn-m7-pr4-render-diagnostics
./apply.sh ~/Projects/openvn
```

## Build and run

```bash
cd ~/Projects/openvn
./scripts/build-m68k-demo-player.sh
fs-uae "$HOME/Projects/openvn/examples/demo/dist/fs-uae/OpenVNDemo.fs-uae"
```

Close FS-UAE after the gray screen appears, then inspect:

```bash
cat ~/Projects/openvn/examples/demo/dist/fs-uae/harddrive/OpenVN/openvn-render.log
```

Upload or paste that log for the next fix.

## Restore

```bash
cp \
  ~/Projects/openvn/runtimes/amiga-native/src/graphics_amiga.c.pre-m7-pr4 \
  ~/Projects/openvn/runtimes/amiga-native/src/graphics_amiga.c
```
