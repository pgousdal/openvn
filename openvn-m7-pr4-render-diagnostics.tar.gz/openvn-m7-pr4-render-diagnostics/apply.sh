#!/usr/bin/env bash
set -euo pipefail

repo="${1:-$HOME/Projects/openvn}"
source_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/files"
target="$repo/runtimes/amiga-native/src/graphics_amiga.c"

if [[ ! -f "$target" ]]; then
  echo "error: OpenVN source not found: $target" >&2
  exit 1
fi

backup="${target}.pre-m7-pr4"
if [[ ! -e "$backup" ]]; then
  cp -a "$target" "$backup"
fi

cp -a "$source_dir/runtimes/amiga-native/src/graphics_amiga.c" "$target"

echo "Applied M7 PR4 render diagnostics."
echo "Backup: $backup"
echo "Runtime log after launch:"
echo "  $repo/examples/demo/dist/fs-uae/harddrive/OpenVN/openvn-render.log"
